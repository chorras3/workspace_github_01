
//package tmp_borrable;   // For Home workspace
package src.tmp_borrable;	//For Atocha workspace

import java.lang.reflect.Field;

public class Main {
	
	public static void main(String[] args){
		Main app = new Main();
//		app.test01();
		app.test02();
		System.exit(0);
	}
	
	
	private void test01(){
		System.out.println("test01");
		
		Contact contact = new Contact();
		contact.setName("Arnold");
		contact.setLocation("Austria");
		
		System.out.println("contact.toString()="+contact.toString());
		
		System.out.println("End");

	}
	
	
	
	private void test02(){
		System.out.println("test02");
		
		final String TAG_FIELD_VALUE ="zFIELD_VALUEz";
		
		
		
		
		
		Contact contact = new Contact();
		
//		Field[] fieldsArr = contact.getClass().getDeclaredFields();
//		for (int i = 0; i < fieldsArr.length; i++) {
//			Field curField = fieldsArr[0];
//			
//		}

		System.out.println("class contact empty: contact="+contact);

				
		// options: force default value to fill some fields: location, prueba: 
		fillBean(contact, TAG_FIELD_VALUE+"location:Madrid,email:email prueba");
		
		
/*
		// No options. Fill using generic default values in all fields
		fillBean(contact, "");
		
*/
				
		
		System.out.println("class contact filled: contact="+contact);
		
		
		

	}

	
	
	
	
	
	//NOTA: ver abajo el m�todo comentado: setFieldValue y la web de referencia, parece simplificar el SET. 
	
	
	
	
	
	// Receives: bean, options as CSV.
	// References: ** "", https://stackoverflow.com/questions/14374878/using-reflection-to-set-an-object-property
	public <T> T fillBean(T object, String options){
		Object fieldValue = null;
		final boolean TRUE_boolean=true;
//		final String TAG_FIELD_VALUE ="@FIELD_VALUE@";
		final String TAG_FIELD_VALUE ="zFIELD_VALUEz";
		
		final String DEFAULT_String_VALUE="1";
		final Long DEFAULT_Long_VALUE=new Long(1);
		final long DEFAULT_long_VALUE=1;
		final Boolean DEFAULT_Boolean_VALUE=true;
		final boolean DEFAULT_boolean_VALUE=true;
		

		// (...) TO-DO terminarlo
		
		// If options parameter not empty: Replace options (force alternative default values):
		// =====
		
// Test map. References: ** "", https://stackoverflow.com/questions/31153753/split-string-into-key-value-pairs		
		java.util.Map<String, String> map = new java.util.HashMap<String, String>();
	    String test = "pet:cat::car:honda::location:Japan::food:sushi";

	    // split on ':' and on '::'
	    String[] parts = test.split("::?");

	    for (int i = 0; i < parts.length; i += 2) {
	        map.put(parts[i], parts[i + 1]);
	    }

	    for (String s : map.keySet()) {
	        System.out.println(s + " is " + map.get(s));
	    }
		
		
		// DEFAULT_String_VALUE = "new value"
		// (...) TO-DO
		String[] fieldValueArr=null;
//		java.util.Map fieldValueMap=null;
		java.util.Map<String, String> fieldValueMap = new java.util.HashMap<String, String>();

		if (options!=""){
			if (options.toString().indexOf(TAG_FIELD_VALUE) != -1){
				String fieldValueListAsCsvString = options.substring(TAG_FIELD_VALUE.length(), options.length());
				fieldValueArr = fieldValueListAsCsvString.split(TAG_FIELD_VALUE+"?");
//				String[] parts2 = options.split(",?");
//				String[] parts2 = options.split(",");
//				String[] parts2 = options.split(",?|:?");  // Split if exist delimiter ',' or ':'
//				String[] parts2 = options.split(",?|:?");  // Split if exist delimiter ',' or ':'
				String[] parts2 = fieldValueListAsCsvString.split("(,)|(:)");  // Split if exist delimiter ',' or ':'
			    for (int i = 0; i < parts2.length; i += 2) {  // Every correlated pair of parts goes to map 
			    	fieldValueMap.put(parts2[i], parts2[i + 1]);
			    }
			    for (Object s : fieldValueMap.keySet()) {    // Print map
			        System.out.println(s + " is " + fieldValueMap.get(s));
			    }

			}
		}

		
		
	    Class<?> clazz = object.getClass();
		Field[] fieldsArr = object.getClass().getDeclaredFields();
		
		for (int i = 0; i < fieldsArr.length; i++) {
			// Read field
            //=====
			Field currentField = fieldsArr[i];
			String fieldNameAux = currentField.getName();
			
			////String curFieldTypeStr = curField.getType().getName();
			////System.out.println(curField.getName()+";"+curFieldTypeStr);
			
			// Read value
            //=====			
			
			if (currentField.getType().getName().equals("java.lang.String")){
				if (fieldValueMap.get(fieldNameAux)==null ){
					fieldValue=fieldNameAux+" "+DEFAULT_String_VALUE;
//				// But if options parameter specifies an override value for this field...
//				if ( fieldValueArr!=null && fieldValueArr.toString().indexOf(fieldNameStr)>0 ){
//					fieldValue=fieldNameStr+" "+DEFAULT_String_VALUE;
//				}
				// But if options parameter specifies an override value for this field...
				} else {
					// new Default value: 
					fieldValue=fieldValueMap.get(fieldNameAux);  
				}
				
			} else if (currentField.getType().getName().equals("java.lang.Long")){
				fieldValue=DEFAULT_Long_VALUE;
			} else {
				fieldValue=null;
			}

// TRY02 Write                      
			// Write value 
          //=====
            // Set: "We want to access private fields":
            currentField.setAccessible(true);
            try {
            	currentField.set(object, fieldValue);
			} catch (IllegalArgumentException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			} catch (IllegalAccessException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
            
		} // end: "for each field..."
		
		
		System.out.println("object"+object);
		
		return object;
	}
	
	
/*	
	// References: ** "", https://stackoverflow.com/questions/14374878/using-reflection-to-set-an-object-property
	public static boolean setFieldValue(Object object, String fieldName, Object fieldValue) {
	    Class<?> clazz = object.getClass();
	    while (clazz != null) {
	        try {
	            Field field = clazz.getDeclaredField(fieldName);
	            field.setAccessible(true);
	            field.set(object, fieldValue);
	            return true;
	        } catch (NoSuchFieldException e) {
	            clazz = clazz.getSuperclass();
	        } catch (Exception e) {
	            throw new IllegalStateException(e);
	        }
	    }
	    return false;
	}
*/	
	
}
