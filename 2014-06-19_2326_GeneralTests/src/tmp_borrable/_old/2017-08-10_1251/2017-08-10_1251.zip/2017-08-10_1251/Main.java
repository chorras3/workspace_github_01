package tmp_borrable;   // For Home and Alvento workspace
//package src.tmp_borrable;	//For Atocha workspace

import java.lang.reflect.Field;

public class Main {
	
	public static void main(String[] args){
		Main app = new Main();
//		app.test01();
		app.test02();
		System.exit(0);
	}
	
	
	private void test01(){
		System.out.println("test01");
		
		Contact contact = new Contact();
		contact.setName("Arnold");
		contact.setLocation("Austria");
		
		System.out.println("contact.toString()="+contact.toString());
		
		System.out.println("End");

	}
	
	
	
	private void test02(){
		System.out.println("test02"); 
		
		final String TAG_FIELD_VALUE_INIT ="<FIELD_VALUE>";
		final String TAG_FIELD_VALUE_END ="</FIELD_VALUE>";

		Contact contact = new Contact();
		System.out.println("class contact empty: contact="+contact);
		
/*
		// Do not use options. Fill using generic default values in all fields
		fillBean(contact, "");
		System.out.println("class contact filled: contact="+contact);
*/
		

/*		
		// Use options: force default value to fill some fields: location, prueba: 
		objectFill(contact, "<FIELD_VALUE>location:Madrid,email:correo@correo.es,location:calle Pez 2/, prueba con /, comas</FIELD_VALUE>");
		System.out.println("class contact filled: contact="+contact);
*/

		
	    // Crear 2 elementos con direccion Madrid		
		System.out.println("FILLING AT LOOP ============");
		java.util.List direccionesMadList = new java.util.ArrayList();
		for (int i = 1; i <= 2; i++) {
			objectFill(contact, "<FIELD_VALUE>id:"+i+"</FIELD_VALUE>");
			System.out.println("class contact filled: contact="+contact);
			
		}
		/**/		


		
		
		// TODO: 
		//*Use of loops and .add to configure lists
		//*Consider adding list on every element of the main list, since this will be the real scenario. E.g. aCustomerBean.add(aCustomerAdressList). 
		//*Remember to give example of adding a list to another to extend it: aCustomerAdressList1.add(aCustomerAdressList2)
		


	}

	
	
	
	
	
	//NOTA: ver abajo el m�todo comentado: setFieldValue y la web de referencia, parece simplificar el SET. 
	
	
	
	
	
	// Receives: bean, options as CSV.
	// References: ** "", https://stackoverflow.com/questions/14374878/using-reflection-to-set-an-object-property
	public <T> T objectFill(T object, String options){
//		Object valueAsString = null;
		String valueAsString = null;
		final boolean TRUE_boolean=true;
		final String TAG_FIELD_VALUE_INIT ="<FIELD_VALUE>";
		final String TAG_FIELD_VALUE_END ="</FIELD_VALUE>";
		// Parameter 'object' could include this simbol, which means that 
		// within a value there is literally a real comma (not a code separator): \,
		final String COMMA_ESCAPPED ="/,";
		final String COMMA_CODIFIED ="$$COMMA$$";
		final String COMMA_REAL=",";
		
		final String DEFAULT_String_VALUE="1";
		final Long DEFAULT_Long_VALUE=new Long(1);
		final long DEFAULT_long_VALUE=1;
		final Boolean DEFAULT_Boolean_VALUE=true;
		final boolean DEFAULT_boolean_VALUE=true;
		

		// (...) TO-DO terminarlo
		
		
		
/*		
// Test map. References: ** "Split string into key-value pairs", https://stackoverflow.com/questions/31153753/split-string-into-key-value-pairs		
		java.util.Map<String, String> map = new java.util.HashMap<String, String>();
	    String test = "pet:cat::car:honda::location:Japan::food:sushi";

	    // split on ':' and on '::'
	    String[] partsTest = test.split("::?");

	    for (int i = 0; i < partsTest.length; i += 2) {
	        map.put(partsTest[i], partsTest[i + 1]);
	    }

	    for (String s : map.keySet()) {
	        System.out.println(s + " is " + map.get(s));
	    }
    
*/	    

		
		
		
		// Get OPTION info
		// Obtain fieldValueMap. Contains the values that must be forced later. 
		// -If there exist options (param "options") get the fieldValueMap (map having pairs: field and default value for it, as desired)
		// -If options parameter not empty: Replace options (force alternative default values):		
		// -References: ** "Split string into key-value pairs", https://stackoverflow.com/questions/31153753/split-string-into-key-value-pairs
		// =====		
		// DEFAULT_String_VALUE = "new value"
		// (...) TO-DO
		String valuesToForce;
		java.util.Map<String, String> fieldValueMap = new java.util.HashMap<String, String>();
		String[] fieldValueArray=null;
		String fieldValueAsString =null;
//		java.util.Map fieldValueMap=null;
		if (options!=""){
			// Escape a textual comma (this is, the characters: /, ):
			valuesToForce = options;
			if (valuesToForce.toString().indexOf("/,")!=-1){
//				options.replaceAll(COMMA_ESCAPPED, COMMA_CODIFIED);  //FAILS
//				options.replaceAll("/,", COMMA_CODIFIED);  //FAILS
//				options.replaceAll("(/,)", COMMA_CODIFIED);  //FAILS
//				options.replaceAll("[/,]", COMMA_CODIFIED);  //FAILS
				valuesToForce=valuesToForce.replace(COMMA_ESCAPPED, COMMA_CODIFIED);  //FAILS
			}
			
			if (options.toString().indexOf(TAG_FIELD_VALUE_INIT) != -1){
//				fieldValueListAsString = valuesToForce.substring(TAG_FIELD_VALUE_INIT.length(), valuesToForce.length());
				fieldValueAsString = valuesToForce.substring(TAG_FIELD_VALUE_INIT.length(), valuesToForce.length()-TAG_FIELD_VALUE_END.length());
				fieldValueArray = fieldValueAsString.split(TAG_FIELD_VALUE_INIT+"?");
//				String[] parts2 = valuesToForce.split(",?");
//				String[] parts2 = valuesToForce.split(",");
//				String[] parts2 = valuesToForce.split(",?|:?");  // Split if exist delimiter ',' or ':'
//				String[] parts2 = valuesToForce.split(",?|:?");  // Split if exist delimiter ',' or ':'
				String[] parts = fieldValueAsString.split("(,)|(:)");  // Split if exist delimiter ',' or ':'
				// Every correlated pair of parts will go to a map
				for (int i = 0; i < parts.length; i += 2) {   
			    	String elementKey=parts[i];
			    	String elementValue=parts[i + 1];
			    	// UNDO codification of an escaped comma symbol (The text: "/," was replaced by text $$COMMA$$ or similar, so we revert it back):
					if (elementKey.indexOf(COMMA_CODIFIED)!=-1){
						elementKey=elementKey.replace(COMMA_CODIFIED, COMMA_REAL);
					}
					if (elementValue.indexOf(COMMA_CODIFIED)!=-1){
						elementValue=elementValue.replace(COMMA_CODIFIED, COMMA_REAL);
					}
			    	fieldValueMap.put(elementKey, elementValue);
			    }
			    // Log
			    System.out.println("option:valuesToForce. There are the following values to force:");
			    for (Object fieldAux : fieldValueMap.keySet()) {    // Print map
			        System.out.println("Field "+ fieldAux + "=" + fieldValueMap.get(fieldAux));
			    }

			}
		}

		
		// object received: Set values
		// =====
		// Set fields to its force value, if proceed (if options says it so)
	    Class<?> clazz = object.getClass();
		Field[] classFieldsArray = object.getClass().getDeclaredFields();
		
		for (int i = 0; i < classFieldsArray.length; i++) {
			// Read field
            //=====
			Field fieldAux = classFieldsArray[i];
			String fieldNameAux = fieldAux.getName();
			
			// Set value
            //=====			
			if (fieldAux.getType().getName().equals("java.lang.String")){
				// READ
				if (fieldValueMap.get(fieldNameAux)==null ){
					valueAsString=fieldNameAux+" "+DEFAULT_String_VALUE;
//				// But if options parameter specifies an override value for this field...
//				if ( fieldValueArr!=null && fieldValueArr.toString().indexOf(fieldNameStr)>0 ){
//					fieldValue=fieldNameStr+" "+DEFAULT_String_VALUE;
//				}
				// If options parameter specifies to forcean override value for this field...
				} else {
					// new Default value: 
					valueAsString=fieldValueMap.get(fieldNameAux);  
				}
				// WRITE
				// Write value 
				//=====
	            // Set: "We want to access private fields":
	            fieldAux.setAccessible(true);
	            try {
	            	fieldAux.set(object, valueAsString);
				} catch (IllegalArgumentException e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
				} catch (IllegalAccessException e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
				}
				
			} else if (fieldAux.getType().getName().equals("java.lang.Long")){
//				fieldValue=DEFAULT_Long_VALUE;
				if (fieldValueMap.get(fieldNameAux)==null ){
					valueAsString=new Long(DEFAULT_Long_VALUE).toString();
//				// But if options parameter specifies an override value for this field...
//				if ( fieldValueArr!=null && fieldValueArr.toString().indexOf(fieldNameStr)>0 ){
//					fieldValue=fieldNameStr+" "+DEFAULT_String_VALUE;
//				}
				// If options parameter specifies to forcean override value for this field...
				} else {
					// new Default value: 
					valueAsString=fieldValueMap.get(fieldNameAux);  
				}
				// WRITE
				// Write value 
				//=====
	            // Set: "We want to access private fields":
	            fieldAux.setAccessible(true);
	            try {
//		            Long l = new Long(valueAsString);
//	            	Long l = Long.parseLong((String) valueAsString);
	            	Long l = Long.parseLong(valueAsString.toString());
	            	fieldAux.set(object, l);
				} catch (IllegalArgumentException e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
				} catch (IllegalAccessException e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
				}
								
			} else {
				valueAsString=null;
			}

// TRY02 Write                      
//			// Write value 
//          //=====
//            // Set: "We want to access private fields":
//            fieldAux.setAccessible(true);
//            try {
////            	Long l = new Long(valueAsString);
//            	Long l = Long.valueOf((String) valueAsString);
//            	fieldAux.set(object, l);
//			} catch (IllegalArgumentException e) {
//				// TODO Auto-generated catch block
//				e.printStackTrace();
//			} catch (IllegalAccessException e) {
//				// TODO Auto-generated catch block
//				e.printStackTrace();
//			}
            
		} // end: "for each field..."
		
		
		System.out.println("object"+object);
		
		return object;
	}
	
	
/*	
	// References: ** "", https://stackoverflow.com/questions/14374878/using-reflection-to-set-an-object-property
	public static boolean setFieldValue(Object object, String fieldName, Object fieldValue) {
	    Class<?> clazz = object.getClass();
	    while (clazz != null) {
	        try {
	            Field field = clazz.getDeclaredField(fieldName);
	            field.setAccessible(true);
	            field.set(object, fieldValue);
	            return true;
	        } catch (NoSuchFieldException e) {
	            clazz = clazz.getSuperclass();
	        } catch (Exception e) {
	            throw new IllegalStateException(e);
	        }
	    }
	    return false;
	}
*/	
	
}
